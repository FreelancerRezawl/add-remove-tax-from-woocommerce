<?php
/**
 * Plugin Name: TIN Checkout Tax Removal
 * Description: Removes VAT from the WooCommerce checkout if a TIN number is provided.
 * Version: 1.0.0
 * Author: Alex Reza
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Add the TIN field to the checkout page
add_action('woocommerce_after_order_notes', 'tin_add_custom_checkout_field');

function tin_add_custom_checkout_field($checkout)
{
    woocommerce_form_field('tin_number', array(
        'type'          => 'text',
        'class'         => array('form-row-wide'),
        'label'         => __('TIN Number'),
        'placeholder'   => __('Enter your TIN number if applicable'),
        'required'      => false,
    ), $checkout->get_value('tin_number'));
}

// Save TIN number in order meta
add_action('woocommerce_checkout_update_order_meta', 'tin_checkout_field_update_order_meta');

function tin_checkout_field_update_order_meta($order_id)
{
    if (!empty($_POST['tin_number'])) {
        update_post_meta($order_id, 'tin_number', sanitize_text_field($_POST['tin_number']));
    }
}

// Remove tax if TIN number is provided
add_action('woocommerce_cart_calculate_fees', 'tin_remove_vat_if_tin_provided');

function tin_remove_vat_if_tin_provided()
{
    if (is_checkout()) {
        $tin_number = isset($_POST['tin_number']) ? sanitize_text_field($_POST['tin_number']) : '';

        if (!empty($tin_number)) {
            foreach (WC()->cart->get_taxes() as $tax_rate_id => $tax_amount) {
                WC()->cart->remove_fee($tax_rate_id);
                WC()->cart->set_tax_amount($tax_rate_id, 0);
            }
        }
    }
}

// Display TIN number on the order edit page in the admin
add_action('woocommerce_admin_order_data_after_billing_address', 'tin_display_order_data_in_admin');

function tin_display_order_data_in_admin($order)
{
    $tin_number = get_post_meta($order->get_id(), 'tin_number', true);
    if (!empty($tin_number)) {
        echo '<p><strong>' . __('TIN Number') . ':</strong> ' . esc_html($tin_number) . '</p>';
    }
}
